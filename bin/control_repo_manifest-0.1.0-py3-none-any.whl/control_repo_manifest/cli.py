import os
import sys
import subprocess
from typing import List
from control_repo_manifest.args import parse_args
from analyze_repo_manifest.manifest import parse_manifest
from analyze_repo_manifest.manifest_search import search_manifest
from analyze_repo_manifest.display import get_display_function


def run_bash_script(script_path: str, work_dir: str = ".", args: List[str] = []):
    """
    Run a bash script with optional working directory and arguments.

    :param script_path: Full path to the bash script.
    :param work_dir: Directory to run the script in.
    :param args: List of additional arguments to pass to the script.
    """
    args = [str(arg) for arg in args if arg != ""]

    try:
        result = subprocess.run(
            ["bash", script_path] + args,
            cwd=work_dir,
            check=True,
            capture_output=True,
            text=True
        )
        print(f"✅ SUCCESS: {script_path}\n{result.stdout}")
    except subprocess.CalledProcessError as e:
        print(f"❌ FAILED: {script_path}\n{e.stderr}")


def execute_all_scripts_in_directory(
    scripts_dir: str,
    work_dir: str = ".",
    args: List[str] = []
):
    """
    Execute all .sh files in the given directory in lexicographical order.

    :param scripts_dir: Directory where .sh scripts are stored.
    :param work_dir: Working directory for script execution.
    :param args: Arguments to pass to each script.
    """
    if not os.path.isdir(scripts_dir):
        print(f"❌ Not a directory: {scripts_dir}")
        return

    scripts = [
        os.path.join(scripts_dir, f)
        for f in os.listdir(scripts_dir)
        if f.endswith(".sh") and os.path.isfile(os.path.join(scripts_dir, f))
    ]
    scripts.sort()

    for script in scripts:
        run_bash_script(script, work_dir, args)


def main():
    args = parse_args()

    _, src_root = parse_manifest(args.src_manifest, include_processing=True)
    _, dst_root = parse_manifest(args.dst_manifest, include_processing=True)

    filters = {
        "name": args.name,
        "path": args.path,
        "revision": args.revision,
        "remote": args.remote,
        "groups": args.groups,
        "__full_path": args.full_path,
        "__file_path": args.file_path,
    }

    # Add exact_match flag for searching
    src_elements = search_manifest(src_root, 'project', exact_match=args.exact, **{k: v for k, v in filters.items() if v is not None})

    if not src_elements:
        print("No matching elements found in source manifest.", file=sys.stderr)
        sys.exit(1)

    for src_element in src_elements:

        filters = {
            "name": src_element.get('name'),
            "path": src_element.get('path'),
            "revision": args.revision,
            "remote": args.remote,
            "groups": args.groups,
            "__full_path": args.full_path,
            "__file_path": args.file_path,
        }
        dst_elements = search_manifest(dst_root, 'project', exact_match=args.exact, **{k: v for k, v in filters.items() if v is not None})

        print("-" * 80)
        if not dst_elements:
            print(f"No matching elements found in destination manifest for source element: {src_element}", file=sys.stderr)
            continue

        # display_func = get_display_function(args.display)
        # display_func(dst_elements, args.fields)

        dst_element = dst_elements[0]

        script_args = [
            src_element.get('name', None),              # 1
            src_element.get('path', None),              # 2
            src_element.get('revision', None),          # 3
            src_element.get('remote', None),            # 4
            src_element.get('groups', None),            # 5
            src_element.get('__full_path', None),       # 6
            src_element.get('__file_path', None),       # 7
            None,                                       # 8 reserved for future use
            None,                                       # 9 reserved for future use
            None,                                       # 10 reserved for future use
            dst_element.get('name', None),              # 11
            dst_element.get('path', None),              # 12
            dst_element.get('revision', None),          # 13
            dst_element.get('remote', None),            # 14
            dst_element.get('groups', None),            # 15
            dst_element.get('__full_path', None),       # 16
            dst_element.get('__file_path', None),       # 17
            None,                                       # 18 reserved for future use
            None,                                       # 19 reserved for future use
            None,                                       # 20 reserved for future use
        ]

        execute_all_scripts_in_directory(os.path.abspath(args.script_directory), args.work_directory, script_args)
