import os
import sys
import subprocess
from typing import List
from urllib.parse import urljoin
from control_repo_manifest.args import parse_args
from analyze_repo_manifest.manifest import parse_manifest
from analyze_repo_manifest.manifest_search import search_manifest
from analyze_repo_manifest.display import get_display_function


def run_bash_script(script_path: str, work_dir: str = ".", args: List[str] = []):
    """
    Run a bash script with optional working directory and arguments.

    :param script_path: Full path to the bash script.
    :param work_dir: Directory to run the script in.
    :param args: List of additional arguments to pass to the script.
    """
    args = [str(arg) for arg in args if arg != ""]

    try:
        result = subprocess.run(
            ["bash", script_path] + args,
            check=True,
            capture_output=True,
            text=True
        )
        print(f"✅ SUCCESS: {script_path}\n{result.stdout}")
    except subprocess.CalledProcessError as e:
        print(f"❌ FAILED: {script_path}\n{e.stderr}")


def execute_all_scripts_in_directory(
    scripts_dir: str,
    work_dir: str = ".",
    args: List[str] = []
):
    """
    Execute all .sh files in the given directory in lexicographical order.

    :param scripts_dir: Directory where .sh scripts are stored.
    :param work_dir: Working directory for script execution.
    :param args: Arguments to pass to each script.
    """
    if not os.path.isdir(scripts_dir):
        print(f"❌ Not a directory: {scripts_dir}")
        return

    scripts = [
        os.path.join(scripts_dir, f)
        for f in os.listdir(scripts_dir)
        if f.endswith(".sh") and os.path.isfile(os.path.join(scripts_dir, f))
    ]
    scripts.sort()

    for script in scripts:
        run_bash_script(script, work_dir, args)


def main():
    args = parse_args()

    _, src_root = parse_manifest(args.src_manifest, include_processing=True)
    _, dst_root = parse_manifest(args.dst_manifest, include_processing=True)

    filters = {
        "name": args.name,
        "path": args.path,
        "revision": args.revision,
        "remote": args.remote,
        "groups": args.groups,
        "__full_path": args.full_path,
        "__file_path": args.file_path,
    }

    # Add exact_match flag for searching
    src_elements = search_manifest(src_root, 'project', exact_match=args.exact, **{k: v for k, v in filters.items() if v is not None})

    if not src_elements:
        print("No matching elements found in source manifest.", file=sys.stderr)
        sys.exit(1)

    count = 0
    for src_element in src_elements:

        count += 1

        filters = {
            "name": src_element.get('name'),
            "path": src_element.get('path'),
            "revision": args.revision,
            "remote": args.remote,
            "groups": args.groups,
            "__full_path": args.full_path,
            "__file_path": args.file_path,
        }
        dst_elements = search_manifest(dst_root, 'project', exact_match=args.exact, **{k: v for k, v in filters.items() if v is not None})

        print("-" * 3, f"({count}/{len(src_elements)})", "-" * 80)

        if not dst_elements:
            print(f"No matching elements found in destination manifest for source element: {src_element}", file=sys.stderr)
            continue

        # display_func = get_display_function(args.display)
        # display_func(dst_elements, args.fields)

        dst_element = dst_elements[0]

        src_name = src_element.get('name', "")
        src_full_path = src_element.get('__full_path', "")
        src_file_path = src_element.get('__file_path', "")

        dst_name = dst_element.get('name', "")
        dst_full_path = dst_element.get('__full_path', "")
        dst_file_path = dst_element.get('__file_path', "")

        src_remote_path = src_element.get('__remote', "")
        dst_remote_path = dst_element.get('__remote', "")

        script_args = [
            os.path.abspath(args.work_directory),                                               # 1
            os.path.abspath(os.path.join(args.work_directory, dst_full_path)),                  # 2
            os.path.abspath(os.path.dirname(args.src_manifest)),                                # 3
            os.path.abspath(os.path.dirname(args.dst_manifest)),                                # 4
            os.path.abspath(os.path.join(os.path.dirname(args.src_manifest), src_file_path)),   # 5
            os.path.abspath(os.path.join(os.path.dirname(args.dst_manifest), dst_file_path)),   # 6
            urljoin(src_remote_path, src_name),                                                 # 7
            urljoin(dst_remote_path, dst_name),                                                 # 8
            None,                                                                               # 9 reserved for future use
            None,                                                                               # 10 reserved for future use
            src_element.get('name', None) or None,                                              # 11
            src_element.get('path', None) or None,                                              # 12
            src_element.get('revision', None) or None,                                          # 13
            src_element.get('remote', None) or None,                                            # 14
            src_element.get('groups', None) or None,                                            # 15
            src_element.get('upstream', None) or None,                                          # 16
            src_element.get('__full_path', None) or None,                                       # 17
            src_element.get('__file_path', None) or None,                                       # 18
            src_element.get('__remote', None) or None,                                          # 19
            None,                                                                               # 20 reserved for future use
            None,                                                                               # 21 reserved for future use
            None,                                                                               # 22 reserved for future use
            None,                                                                               # 23 reserved for future use
            None,                                                                               # 24 reserved for future use
            None,                                                                               # 25 reserved for future use
            None,                                                                               # 26 reserved for future use
            None,                                                                               # 27 reserved for future use
            None,                                                                               # 28 reserved for future use
            None,                                                                               # 29 reserved for future use
            None,                                                                               # 30 reserved for future use
            dst_element.get('name', None) or None,                                              # 31
            dst_element.get('path', None) or None,                                              # 32
            dst_element.get('revision', None) or None,                                          # 33
            dst_element.get('remote', None) or None,                                            # 34
            dst_element.get('groups', None) or None,                                            # 35
            dst_element.get('upstream', None) or None,                                          # 36
            dst_element.get('__full_path', None) or None,                                       # 37
            dst_element.get('__file_path', None) or None,                                       # 38
            dst_element.get('__remote', None) or None,                                          # 39
            None,                                                                               # 40 reserved for future use
            None,                                                                               # 41 reserved for future use
            None,                                                                               # 42 reserved for future use
            None,                                                                               # 43 reserved for future use
            None,                                                                               # 44 reserved for future use
            None,                                                                               # 45 reserved for future use
            None,                                                                               # 46 reserved for future use
            None,                                                                               # 47 reserved for future use
            None,                                                                               # 48 reserved for future use
            None,                                                                               # 49 reserved for future use
            None,                                                                               # 50 reserved for future use
        ]

        execute_all_scripts_in_directory(os.path.abspath(args.script_directory), args.work_directory, script_args)
