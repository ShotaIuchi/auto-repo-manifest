import sys
from analyze_repo_manifest.args import parse_args, parse_set_fields
from analyze_repo_manifest.manifest_update import update_elements
from analyze_repo_manifest.manifest import parse_manifest
from analyze_repo_manifest.manifest_search import search_manifest
from analyze_repo_manifest.display import get_display_function


def main():
    args = parse_args()

    filters = {
        "name": args.name,
        "path": args.path,
        "revision": args.revision,
        "remote": args.remote,
        "groups": args.groups,
        "alias": args.alias,
        "fetch": args.fetch,
        "pushurl": args.pushurl,
        "review": args.review,
        "manifest-name": args.manifest_name,
        "project": args.project,
        "__remote": args.remote,
        "__full_path": args.full_path,
        "__file_path": args.file_path,
    }

    if args.update:
        # Force exact matching when updating (don't use regex)
        updates = parse_set_fields(args.set)
        update_elements(args.manifest, updates, {k: v for k, v in filters.items() if v is not None})
        return

    _, search_root = parse_manifest(args.manifest, include_processing=True)

    # Add exact_match flag for searching
    elements = search_manifest(search_root, args.command, exact_match=args.exact, **{k: v for k, v in filters.items() if v is not None})

    if not elements:
        print("No matching elements found.", file=sys.stderr)
        sys.exit(1)

    display_func = get_display_function(args.display)
    display_func(elements, args.fields)
