from lxml import etree
import os
import sys


def update_elements(manifest_path, updates: dict, filters: dict):
    """
    Update elements in the manifest file and its includes/submanifests based on filters.

    This function modifies XML elements in a manifest file and its referenced `<include>`
    and `<submanifest>` files. It applies updates to elements that match the specified
    filters and ensures that circular references are avoided.

    Args:
        manifest_path (str): Path to the main manifest XML file.
        updates (dict): A dictionary of attribute updates to apply to matching elements.
                        Keys represent attribute names, and values represent the new values.
        filters (dict): A dictionary of filters to match elements. Keys represent attribute
                        names, and values represent the expected values for filtering.

    Returns:
        None

    Warnings:
        Prints warnings to `stderr` if a file cannot be parsed or if circular references
        are detected.

    Example:
        updates = {"revision": "main", "path": "new/path"}
        filters = {"name": "example-project"}
        update_elements("default.xml", updates, filters)
    """
    processed_files = set()
    base_path = os.path.dirname(os.path.abspath(manifest_path))

    def process_file(file_path):
        """
        Process a single manifest file, applying updates to matching elements.

        Args:
            file_path (str): Path to the manifest file to process.

        Returns:
            None

        Warnings:
            Prints warnings to `stderr` if the file cannot be parsed or if circular
            references are detected.
        """
        if file_path in processed_files:
            return

        try:
            tree = etree.parse(file_path)
        except (etree.XMLSyntaxError, OSError) as e:
            print(f"Error: Failed to parse file '{file_path}': {e}", file=sys.stderr)
            return

        root = tree.getroot()
        processed_files.add(file_path)

        # Find elements matching the filters
        xpath = _build_xpath("project", **filters)
        elements = root.xpath(xpath)

        # Update matching elements
        for elem in elements:
            for key, value in updates.items():
                elem.set(key.replace("_", "-"), value)

        # Process includes
        for include in root.xpath("//include"):
            include_name = include.get("name")
            if include_name:
                include_path = os.path.join(base_path, include_name)
                process_file(include_path)

        # Process submanifests
        for submanifest in root.xpath("//submanifest"):
            submanifest_name = submanifest.get("manifest-name")
            if submanifest_name:
                submanifest_path = os.path.join(base_path, submanifest_name)
                process_file(submanifest_path)

        # Save the updated file
        save_manifest(tree, file_path)

    # Start processing from the main manifest file
    process_file(manifest_path)


def save_manifest(tree, path: str):
    """
    Save the XML tree back to a file with pretty print formatting.

    Args:
        tree (ElementTree): The XML tree to save.
        path (str): Path to the file where the XML tree should be saved.

    Returns:
        None

    Example:
        save_manifest(tree, "updated_manifest.xml")
    """
    tree.write(path, pretty_print=True, encoding="utf-8", xml_declaration=True)


def _build_xpath(command, **filters):
    """
    Build an XPath string based on the command type and filter conditions.

    This function generates an XPath query to locate elements in the XML tree
    that match the specified filters.

    Args:
        command (str): The type of element to search for ("project", "remote", "submanifest").
        **filters: Attribute filters as key-value pairs. Keys represent attribute names,
                   and values represent the expected values for filtering.

    Returns:
        str: An XPath query string.

    Raises:
        ValueError: If the command type is unknown.

    Example:
        xpath = _build_xpath("project", name="example-project", revision="main")
    """
    if command == "project":
        base = "//project"
    elif command == "remote":
        base = "//remote"
    elif command == "submanifest":
        base = "//submanifest"
    else:
        raise ValueError(f"Unknown command: {command}")

    conds = []
    for key, value in filters.items():
        if value is not None:
            conds.append(f'@{key}="{value}"')

    if conds:
        return f'{base}[{" and ".join(conds)}]'
    else:
        return base
