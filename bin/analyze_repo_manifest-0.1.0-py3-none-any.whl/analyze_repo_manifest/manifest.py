import copy
import os
import sys
from lxml import etree


def parse_manifest(path: str, include_processing=True):
    """
    Parse a manifest XML file and return its tree and root element.

    This function reads an XML manifest file, parses it into an ElementTree,
    and optionally processes `<include>` and `<submanifest>` tags to resolve
    their contents recursively.

    Args:
        path (str): Path to the manifest XML file.
        include_processing (bool): If True, process `<include>` and `<submanifest>` tags
            to resolve their contents. Defaults to True.

    Returns:
        tuple: A tuple containing:
            - tree (ElementTree): The parsed XML tree.
            - root (Element): The root element of the XML tree.

    Raises:
        ValueError: If the XML file cannot be parsed due to syntax errors or
            if the file cannot be read.

    Example:
        tree, root = parse_manifest("default.xml", include_processing=True)
    """
    try:
        tree = etree.parse(path)
    except (etree.XMLSyntaxError, OSError) as e:
        raise ValueError(f"Failed to parse manifest file '{path}': {e}")

    root = tree.getroot()

    # Use the updated annotation function
    parent_remote = _annotate_tree_elements_with_source_and_remote(root, os.path.basename(path))

    if include_processing:
        base_path = os.path.dirname(os.path.abspath(path))
        processed_files = set()  # Track processed files to detect circular references
        _process_includes(root, base_path, processed_files, parent_remote)
        _process_submanifests(root, base_path, processed_files, parent_remote)

    return tree, root


def _process_includes(root, base_path, processed_files, parent_remote=None):
    """
    Process `<include>` tags in the manifest by replacing them with their contents.

    This function resolves `<include>` tags by loading the referenced XML files,
    parsing their contents, and inserting them into the current manifest tree.
    It also ensures that circular references are avoided.

    Args:
        root (Element): The root element of the current manifest tree.
        base_path (str): The base directory of the manifest file.
        processed_files (set): A set of file paths that have already been processed
            to prevent circular references.
        parent_remote (dict): The parent's remote fetch mappings and default remote.

    Returns:
        None

    Warnings:
        Prints warnings to `stderr` if an `<include>` tag is missing the `name`
        attribute, if the referenced file does not exist, or if the file cannot
        be parsed.

    Example:
        _process_includes(root, "/path/to/manifest", set())
    """
    includes = root.xpath(".//include")
    for include in includes:
        include_name = include.get("name")
        if not include_name:
            print("Warning: include without name", file=sys.stderr)
            continue

        include_path = os.path.join(base_path, include_name)
        if include_path in processed_files:
            continue  # prevent circular include

        if not os.path.exists(include_path):
            print(f"Warning: include file not found: {include_path}", file=sys.stderr)
            continue

        try:
            include_tree = etree.parse(include_path)
            include_root = include_tree.getroot()
        except Exception as e:
            print(f"Error parsing include {include_path}: {e}", file=sys.stderr)
            continue

        # Pass parent_remote to the child
        child_remote = _annotate_tree_elements_with_source_and_remote(include_root, include_name, parent_remote)

        _process_includes(include_root, base_path, processed_files, child_remote)
        _process_submanifests(include_root, base_path, processed_files, child_remote)

        parent = include.getparent()
        insert_index = parent.index(include)
        parent.remove(include)
        for child in include_root:
            parent.insert(insert_index, child)
            insert_index += 1

        processed_files.add(include_path)


def _process_submanifests(root, base_path, processed_files, parent_remote=None):
    """
    Process `<submanifest>` tags in the manifest by adding their projects.

    This function resolves `<submanifest>` tags by loading the referenced XML files,
    parsing their contents, and merging their `<project>` elements into the current
    manifest tree. It also ensures that circular references are avoided.

    Args:
        root (Element): The root element of the current manifest tree.
        base_path (str): The base directory of the manifest file.
        processed_files (set): A set of file paths that have already been processed
            to prevent circular references.
        parent_remote (dict): The parent's remote fetch mappings and default remote.

    Returns:
        None

    Warnings:
        Prints warnings to `stderr` if a `<submanifest>` tag is missing the
        `manifest-name` attribute, if the referenced file does not exist, or
        if the file cannot be parsed.

    Example:
        _process_submanifests(root, "/path/to/manifest", set())
    """
    submanifests = root.xpath(".//submanifest")
    for submanifest in submanifests:
        manifest_name = submanifest.get("manifest-name")
        if not manifest_name:
            print(f"Warning: submanifest without manifest-name attribute", file=sys.stderr)
            continue

        submanifest_path = os.path.join(base_path, manifest_name)
        if submanifest_path in processed_files:
            continue  # prevent circular reference

        if not os.path.exists(submanifest_path):
            print(f"Warning: submanifest file not found: {submanifest_path}", file=sys.stderr)
            continue

        try:
            sub_tree = etree.parse(submanifest_path)
            sub_root = sub_tree.getroot()
        except Exception as e:
            print(f"Error parsing submanifest {submanifest_path}: {e}", file=sys.stderr)
            continue

        # Pass parent_remote to the child
        child_remote = _annotate_tree_elements_with_source_and_remote(sub_root, manifest_name, parent_remote)

        _process_includes(sub_root, base_path, processed_files, child_remote)
        _process_submanifests(sub_root, base_path, processed_files, child_remote)

        parent = submanifest.getparent()
        insert_index = parent.index(submanifest)
        parent.remove(submanifest)
        for project in sub_root.xpath(".//project"):
            new_project = etree.Element("project")
            for key, value in project.attrib.items():
                new_project.set(key, value)

            project_path_prefix = submanifest.get("path") or submanifest.get("project")
            if project_path_prefix:
                orig_path = project.get("path", "")
                new_project.set("__full_path", os.path.join(project_path_prefix, orig_path))

            parent.insert(insert_index, new_project)
            insert_index += 1

        processed_files.add(submanifest_path)


def _annotate_tree_elements_with_source_and_remote(root, current_file_path, parent_remote=None):
    """
    Annotate XML elements with their source file path and remote fetch.

    This function adds a `__full_path` attribute to each XML element in the tree,
    indicating the file from which the element originated. It also adds a `__remote`
    attribute to `<project>` elements, indicating the `fetch` value of the corresponding
    `<remote>` tag. If no remote is defined in the current file, it inherits from the parent.

    Args:
        root (Element): The root element of the XML tree.
        current_file_path (str): The path to the XML file being processed.
        parent_remote (dict): A dictionary containing the parent's remote fetch mappings
                              and default remote.

    Returns:
        dict: A dictionary containing the current file's remote fetch mappings and default remote.

    Example:
        _annotate_tree_elements_with_source_and_remote(root, "/path/to/manifest.xml", parent_remote)
    """
    # Annotate all elements with source file
    # source_path = os.path.abspath(current_file_path)
    for elem in root.iter():
        if isinstance(elem.tag, str):  # exclude comments, PIs, etc.
            elem.set("__file_path", current_file_path)

    # Collect remote fetch mappings
    remote_fetch_map = parent_remote["remote_fetch_map"].copy() if parent_remote else {}
    default_remote = parent_remote["default_remote"] if parent_remote else None

    for remote in root.xpath("//remote"):
        name = remote.get("name")
        fetch = remote.get("fetch")
        if name and fetch:
            remote_fetch_map[name] = fetch

    # Check for default remote
    default = root.find("default")
    if default is not None:
        default_remote = default.get("remote")

    # Annotate projects with __remote
    for project in root.xpath("//project"):
        project_path = project.get("path", "")
        if not project_path:
            project_name = project.get("name")
            project.set("path", project_name)

        remote_name = project.get("remote", default_remote)
        if remote_name:
            if remote_name in remote_fetch_map:
                project.set("__remote", remote_fetch_map[remote_name])
            else:
                project.set("__remote", "unknown")

    # Return the current file's remote information for child processing
    return {"remote_fetch_map": remote_fetch_map, "default_remote": default_remote}


def search_manifest(root, command, **filters):
    """Search elements in manifest using filters"""
    xpath = _build_xpath(command, **filters)
    return root.xpath(xpath)


def update_elements(elements, updates: dict):
    """Update attributes of matched elements"""
    for elem in elements:
        for key, value in updates.items():
            elem.set(key.replace("_", "-"), value)


def save_manifest(tree, path: str):
    """Save the XML tree back to file with pretty print"""
    tree.write(path, pretty_print=True, encoding="utf-8", xml_declaration=True)


def _build_xpath(command, **filters):
    """[internal] Build XPath string based on command type and filter conditions"""
    if command == "project":
        base = "//project"
    elif command == "remote":
        base = "//remote"
    elif command == "submanifest":
        base = "//submanifest"
    else:
        raise ValueError(f"Unknown command: {command}")

    conds = []
    for key, value in filters.items():
        if value is not None:
            conds.append(f'@{key}="{value}"')

    if conds:
        return f'{base}[{" and ".join(conds)}]'
    else:
        return base
