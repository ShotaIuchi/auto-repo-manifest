import sys
from datetime import datetime

EXPIRE_DATE = datetime(2025, 7, 1)

if datetime.now() > EXPIRE_DATE:
    sys.exit("This package has expired. Please contact the author.")
