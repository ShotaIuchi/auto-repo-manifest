from lxml import etree
import re


def search_manifest(root, command, exact_match=False, **filters):
    """
    Search elements in a manifest XML tree using filters.

    This function searches for elements in an XML manifest tree based on the specified
    command type and attribute filters. It supports both exact string matching and
    regular expression-based matching for flexible searches.

    Args:
        root (Element): The root element of the XML tree to search.
        command (str): The type of element to search for. Valid values are:
                       - "project": Search for `<project>` elements.
                       - "remote": Search for `<remote>` elements.
                       - "submanifest": Search for `<submanifest>` elements.
        exact_match (bool): If True, perform exact string matching using XPath.
                            If False, use Python's regex for more flexible matching.
                            Defaults to False.
        **filters: Attribute filters as key-value pairs. Keys represent attribute names,
                   and values represent the expected values or regex patterns for filtering.

    Returns:
        list: A list of matching XML elements.

    Raises:
        ValueError: If the `command` type is invalid or unknown.

    Example:
        # Exact match search
        elements = search_manifest(root, "project", exact_match=True, name="example-project")

        # Regex-based search
        elements = search_manifest(root, "project", exact_match=False, name="^example.*")
    """
    if exact_match:
        # Use traditional XPath search for exact matching
        xpath = _build_xpath(command, **filters)
        return root.xpath(xpath)
    else:
        # For regex search, get elements with basic XPath and then filter with Python
        if command == "project":
            base_xpath = "//project"
        elif command == "remote":
            base_xpath = "//remote"
        elif command == "submanifest":
            base_xpath = "//submanifest"
        else:
            raise ValueError(f"Unknown command: {command}")

        all_elements = root.xpath(base_xpath)
        result = []

        for elem in all_elements:
            match = True
            for key, pattern in filters.items():
                if pattern is None:
                    continue

                attr_value = elem.get(key)
                if attr_value is None:
                    match = False
                    break

                try:
                    if not re.search(pattern, attr_value):
                        match = False
                        break
                except re.error:
                    # Fall back to substring search in case of regex error
                    if pattern not in attr_value:
                        match = False
                        break

            if match:
                result.append(elem)

        return result


def _build_xpath(command, **filters):
    """
    Build an XPath query string based on the command type and filter conditions.

    This function generates an XPath query to locate elements in the XML tree
    that match the specified filters. It is used for exact matching.

    Args:
        command (str): The type of element to search for. Valid values are:
                       - "project": Search for `<project>` elements.
                       - "remote": Search for `<remote>` elements.
                       - "submanifest": Search for `<submanifest>` elements.
        **filters: Attribute filters as key-value pairs. Keys represent attribute names,
                   and values represent the expected values for filtering.

    Returns:
        str: An XPath query string.

    Raises:
        ValueError: If the `command` type is invalid or unknown.

    Example:
        xpath = _build_xpath("project", name="example-project", revision="main")
    """
    if command == "project":
        base = "//project"
    elif command == "remote":
        base = "//remote"
    elif command == "submanifest":
        base = "//submanifest"
    else:
        raise ValueError(f"Unknown command: {command}")

    conds = []
    for key, value in filters.items():
        if value is not None:
            conds.append(f'@{key}="{value}"')

    if conds:
        return f'{base}[{" and ".join(conds)}]'
    else:
        return base
